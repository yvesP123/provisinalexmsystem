function setup()
{
noCanvas();
var timer=select('#timer';
timer.html('0 ');
}
